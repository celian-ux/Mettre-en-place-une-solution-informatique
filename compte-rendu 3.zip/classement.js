var qs = document.location.search
var params = new URLSearchParams(qs)
var id = params.has("id") ? params.get("id") : 42

var url = "http://localhost:8080/VGApi/course?id=" + id
fetch(url).then(r => r.json())
.then(mafonction)

function mafonction(json){
    console.log(json)
    var tableau = document.getElementById("corps-tableau")
    for(var i = 0 ; i < json.length; i++){
        var ligne = document.createElement("tr")
        var crang = document.createElement("td")
        var cskip = document.createElement("td")  
        var cbato = document.createElement("td")
        crang.innerHTML =
        "<span class='badge bg-success'>" +
        json[i]["place"] +
        "</span>"
        cskip.innerHTML =
            "<a href='skipper.html?ids=" + json[i]["ids"] + "'>" +
            json[i]["prenom"] +
            "</a>"

        cbato.innerHTML =
            "<a href='bateau.html?idb=" + json[i]["idb"] + "'>" +
            json[i]["nombateau"] +
            "</a>"
                ligne.appendChild(crang)
                ligne.appendChild(cskip)
                ligne.appendChild(cbato)
                tableau.appendChild(ligne)
            }
        }

var fuse

fetch("http://localhost:8080/VGApi/skipper")
    .then(r => r.json())
    .then(function(liste) {
        fuse = new Fuse(liste, { keys: ['firstname', 'nickname', 'name'] })
    })

document.querySelector("form").addEventListener("submit", function(e) {
    e.preventDefault()
    var texte = document.querySelector("input[type=search]").value
    var resultats = fuse.search(texte)
    var tableau = document.getElementById("corps-tableau")
    tableau.innerHTML = ""

    for (var i = 0; i < resultats.length; i++) {
        var skipper = resultats[i].item
        var ligne = document.createElement("tr")
        var cskip = document.createElement("td")
        cskip.innerHTML = "<a href='skipper.html?id=" + skipper["id"] + "'>" + skipper["firstname"] + " " + skipper["name"] + "</a>"
        ligne.appendChild(cskip)
        tableau.appendChild(ligne)
    }
})