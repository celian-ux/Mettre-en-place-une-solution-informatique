var qs = document.location.search
var params = new URLSearchParams(qs)
var id = params.has("ids") ? params.get("ids") : 42

fetch("http://localhost:8080/VGApi/skipper?id=" + id)
  
    .then(function(json) {
        if (json.length === 0) return

        var prenom = json[0]["prenom"]
        var nom = json[0]["nom"]
        document.getElementById("titre-skipper").innerHTML = prenom + " " + nom
        document.getElementById("nom-skipper").innerHTML = prenom + " " + nom

     
        var tableau = document.getElementById("corps-tableau")
        for (var i = 0; i < json.length; i++) {
            var ligne = document.createElement("tr")
            var cbato = document.createElement("td")
            var cplace = document.createElement("td")

            cbato.innerHTML = "<a href='bateau.html?nom=" + encodeURIComponent(json[i]["nombateau"]) + "'>" + json[i]["nombateau"] + "</a>"
            cplace.innerHTML = json[i]["place"] > 0 ? json[i]["place"] : "Abandon"

            ligne.appendChild(cbato)
            ligne.appendChild(cplace)
            tableau.appendChild(ligne)
        }
    })
   