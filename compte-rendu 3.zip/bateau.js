var qs = document.location.search
var params = new URLSearchParams(qs)
var id = params.has("idb") ? params.get("idb") : 8

fetch("http://localhost:8080/VGApi/bateau?id=" + id)
    .then(r => r.json())
    .then(function(json) {
        console.log(json)

        if (json.length === 0) return
        var nomBateau = json[0]["nombateau"]
        document.getElementById("titre-bateau").innerHTML = nomBateau
       document.getElementById("nom-bateau").innerHTML = nomBateau
        var tableau = document.getElementById("corps-tableau")
        tableau.innerHTML = ""
        
        for (var i = 0; i < json.length; i++) {
            var ligne = document.createElement("tr")
            var cskip = document.createElement("td")
            var cplace = document.createElement("td")
            cskip.innerHTML =
                "<a href='skipper.html?ids=" + json[i]["ids"] + "'>" +
                json[i]["prenom"] + " " + json[i]["nom"] +
                "</a>"
            cplace.innerHTML =
                json[i]["place"] > 0
                ? json[i]["place"]
                : "Abandon"
            ligne.appendChild(cskip)
            ligne.appendChild(cplace)
            tableau.appendChild(ligne)
        }
    })