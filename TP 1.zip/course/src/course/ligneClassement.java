/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package course;

/**
 *
 * @author croch
 */
class ligneClassement {
    private String  nom; 
    private String prenom;
    private String nombateau;
    private int place;
    
    public ligneClassement(int place, String prenom ,String nom ,String nombateau){
    this.place = place;
    this.prenom = prenom;
    this.nom =nom;
    this.nombateau = nombateau;
}
}