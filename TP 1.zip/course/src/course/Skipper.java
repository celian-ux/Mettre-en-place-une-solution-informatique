/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package course;

/**
 *
 * @author croch
 */
public class Skipper {
      private int ids;
    private String nom;
    private String prenom;
    private int naissance;
    private String nationalite;

    public Skipper(int ids, String nom, String prenom, int naissance, String nationalite) {
        this.ids = ids;
        this.nom = nom;
        this.prenom = prenom;
        this.naissance = naissance;
        this.nationalite = nationalite;
    }
}