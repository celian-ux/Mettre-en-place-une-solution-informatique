/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package course;

/**
 *
 * @author croch
 */
public class course1 {
    
    private int idc;
    private String edition;

    public course1(int idc, String edition) {
        this.idc = idc;
        this.edition = edition;
    }
}

