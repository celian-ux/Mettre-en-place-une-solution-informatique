package course;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Collection;
import com.google.gson.Gson;

public class Course {

    public static void main(String[] args) {

        String url = "jdbc:postgresql://postgresql-std-0e1616c7378f.apps.kappsul.su.univ-lorraine.fr:5432/imocadb";
        String user = "postgres";
        String password = "FhYeLnOH6a";

        try (Connection cnx = DriverManager.getConnection(url, user, password)) {

            Gson gson = new Gson();

            // ===== SKIPPERS =====
            PreparedStatement stmtSkipper =
                    cnx.prepareStatement(
                            "SELECT ids, nom, prenom, naissance, nationalite FROM skipper");

            ResultSet rsSkipper = stmtSkipper.executeQuery();

            Collection<Skipper> skippers = new ArrayList<>();

            while (rsSkipper.next()) {
                skippers.add(new Skipper(
                        rsSkipper.getInt("ids"),
                        rsSkipper.getString("nom"),
                        rsSkipper.getString("prenom"),
                        rsSkipper.getInt("naissance"),
                        rsSkipper.getString("nationalite")
                ));
            }

            System.out.println("SKIPPERS :");
            System.out.println(gson.toJson(skippers));


            // ===== BATEAUX =====
            PreparedStatement stmtBateau =
                    cnx.prepareStatement(
                            "SELECT idb, architecte, misealeau FROM bateau");

            ResultSet rsBateau = stmtBateau.executeQuery();

            Collection<Bateau> bateaux = new ArrayList<>();

            while (rsBateau.next()) {
                bateaux.add(new Bateau(
                        rsBateau.getInt("idb"),
                        rsBateau.getString("architecte"),
                        rsBateau.getInt("misealeau")
                ));
            }

            System.out.println("BATEAUX :");
            System.out.println(gson.toJson(bateaux));


            // ===== COURSES =====
            PreparedStatement stmtCourse =
                    cnx.prepareStatement(
                            "SELECT idc, edition FROM course");

            ResultSet rsCourse = stmtCourse.executeQuery();

            Collection<course1> courses = new ArrayList<>();

            while (rsCourse.next()) {
                courses.add(new course1(
                        rsCourse.getInt("idc"),
                        rsCourse.getString("edition")
                ));
            }

            System.out.println("COURSES :");
            System.out.println(gson.toJson(courses));

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}