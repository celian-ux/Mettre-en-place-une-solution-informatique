/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package course;

/**
 *
 * @author croch
 */
public class Bateau {
    private int idb;
    private String architecte;
    private int misealeau;

    // Constructeur
    public Bateau(int idb, String architecte, int misealeau) {
        this.idb = idb;
        this.architecte = architecte;
        this.misealeau = misealeau;
    }
}
