/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package requetes;

import com.google.gson.Gson;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.logging.Level;
import java.util.logging.Logger;
import modele.Ligne_de_classement;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;


/**
 *
 * @author croch
 */
public class Requetes {

    public static String getcourse(int id ){
        
        Collection<Ligne_de_classement> c = new ArrayList<>();
        try{
        InitialContext cxt = new InitialContext();
        DataSource ds = (DataSource) cxt.lookup( "java:/comp/env/jdbc/postgres" );
        try (Connection cnx = ds.getConnection()) {

            PreparedStatement stmt = cnx.prepareStatement(
                    "select place, prenom, nom, nombateau "
                    + "from classement inner join skipper on classement.ids = skipper.ids "
                    + "where idc = ? order by place;"
            );
            stmt.setInt(1, id);
            ResultSet result = stmt.executeQuery();
            while (result.next()) {
                c.add(new Ligne_de_classement(
                        result.getInt("place"),        // place
                        result.getString("nombateau"), // nombateau
                        0,                             // ids
                        result.getString("nom"),       // nom
                        result.getString("prenom"),    // prenom
                        0,                             // naissance
                        null,                          // nationalite
                        0,                             // idb
                        null,                          // architecte
                        null,                          // misealeau
                        0,                             // idc
                        null      

                ));
            }
        } catch (SQLException ex) {
            Logger.getLogger(Requetes.class.getName()).log(Level.SEVERE, null, ex);
        }
        }catch (NamingException e){
            e.printStackTrace();
        }
        Gson gson  = new Gson();
        return gson.toJson(c);
    }

public static String getskipper(int id) {
        Collection<Ligne_de_classement> c = new ArrayList<>();
        try {
            InitialContext cxt = new InitialContext();
            DataSource ds = (DataSource) cxt.lookup("java:/comp/env/jdbc/postgres");
            try (Connection cnx = ds.getConnection()) {
                PreparedStatement stmt = cnx.prepareStatement(
                    "SELECT skipper.ids, skipper.nom, skipper.prenom, skipper.naissance, skipper.nationalite, classement.nombateau, classement.place FROM skipper INNER JOIN classement ON classement.ids = skipper.ids WHERE skipper.ids = ?"
                );
                stmt.setInt(1, id);
                ResultSet result = stmt.executeQuery();
                while (result.next()) {
                    c.add(new Ligne_de_classement(
                         result.getInt("place"),             // place
                        result.getString("nombateau"),      // bateau
                        result.getInt("ids"),               // ids
                        result.getString("nom"),            // nom
                        result.getString("prenom"),         // prenom
                        result.getInt("naissance"),      // naissance
                        result.getString("nationalite"),    // nationalite
                        0,                                  // idb
                        null,                               // architecte
                        null,                               // misealeau
                        0,                                  // idc
                        null         
                    ));
                }
            } catch (SQLException ex) {
                Logger.getLogger(Requetes.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (NamingException e) {
            e.printStackTrace();
        }
        Gson gson = new Gson();
        return gson.toJson(c);
    }
    public static String getallskippers() {
    Collection<Ligne_de_classement> c = new ArrayList<>();
    try {
        InitialContext cxt = new InitialContext();
        DataSource ds = (DataSource) cxt.lookup("java:/comp/env/jdbc/postgres");
        try (Connection cnx = ds.getConnection()) {
            PreparedStatement stmt = cnx.prepareStatement(
                "SELECT ids, nom, prenom, naissance, nationalite FROM skipper ORDER BY nom;"
            );
            ResultSet result = stmt.executeQuery();
            while (result.next()) {
                c.add(new Ligne_de_classement(
                    0, null,
                    result.getInt("ids"),
                    result.getString("nom"),
                    result.getString("prenom"),
                    result.getInt("naissance"),
                    result.getString("nationalite"),
                    0, null, null, 0, null
                ));
            }
        } catch (SQLException ex) {
            Logger.getLogger(Requetes.class.getName()).log(Level.SEVERE, null, ex);
        }
    } catch (NamingException e) {
        e.printStackTrace();
    }
    Gson gson = new Gson();
    return gson.toJson(c);
    }

    public static String getbateau(int id) {
        Collection<Ligne_de_classement> c = new ArrayList<>();
        try {
            InitialContext cxt = new InitialContext();
            DataSource ds = (DataSource) cxt.lookup("java:/comp/env/jdbc/postgres");
            try (Connection cnx = ds.getConnection()) {
                PreparedStatement stmt = cnx.prepareStatement(
                    "select place, prenom, nom, nombateau " +
                    "from classement inner join skipper on classement.ids = skipper.ids " +
                    "where classement.idb = ? order by place;"
                );
                stmt.setInt(1, id);
                ResultSet result = stmt.executeQuery();
                while (result.next()) {
                    c.add(new Ligne_de_classement(
                         result.getInt("place"),             // place
                         result.getString("nombateau"),      // nombateau
                         0,                                  // ids
                         result.getString("nom"),            // nom
                         result.getString("prenom"),         // prenom
                         0,                                  // naissance
                         null,                               // nationalite
                         result.getInt("ibd"),               // idb
                         null,                               // architecte
                         null,                               // misealeau
                         0,                                  // idc
                         null    
                    )); 
                }
            } catch (SQLException ex) {
                Logger.getLogger(Requetes.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (NamingException e) {
            e.printStackTrace();
        }
        Gson gson = new Gson();
        return gson.toJson(c);
    }
}
