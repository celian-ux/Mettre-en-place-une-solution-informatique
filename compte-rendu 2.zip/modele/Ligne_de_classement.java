/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modele;

/**
 *
 * @author croch
 */
public class Ligne_de_classement {
    private int place;
    private String nombateau;
    // Skipper
    private int ids;
    private String nom; 
    private String prenom;
    private int naissance;
    private String nationalite;
    // Bateau
    private int idb;
    private String architecte;
    private String misealeau;
    // Course
    private int idc;
    private String edition;
    
     public Ligne_de_classement(int place, String nombateau, int ids, String nom, String prenom, int naissance, String nationalite, int idb, String architecte, String misealeau, int idc, String edition) {
        this.place = place;
        this.nombateau = nombateau;
        this.ids = ids;
        this.nom = nom;
        this.prenom = prenom;
        this.naissance = naissance;
        this.nationalite = nationalite;
        this.idb = idb;
        this.architecte = architecte;
        this.misealeau = misealeau;
        this.idc = idc;
        this.edition = edition;
    }
}
